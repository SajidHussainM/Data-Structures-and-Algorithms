//Really excited this is my first Program and more to come!

#include<iostream>
using namespace std;

int main()
{
    cout<<"Hello World";
    return 0;
}
